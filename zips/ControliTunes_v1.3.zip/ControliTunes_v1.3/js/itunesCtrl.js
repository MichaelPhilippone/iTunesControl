/* ************************************************************************************
 * 	OBJECT:		
 * 	AUTHOR:		Michael Philippone
 *	DATE:			05 JAN 2011
 *	UPDATED:	11 JAN 2011
 *	PURPOSE:	
************************************************************************************ */
/* ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** **  */
/**	GLOBAL VARS */
var CmdCats = {"ARTIST":1,"TITLE":1,"ALBUM":1,"VOLUME":0,"POSITION":0,"DURATION":1,"PERCENT":0};
var Cmds = {"play":">","pause":"#","previous":"<--","next":"-->","volup":"Vol +","voldown":"Vol -"};
/* ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** **  */
/* ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** **  */

/**	once the page has loaded, assign all the pertinent JS actions 
			PARAM target					-	the element to fill in
			PARAM submissionType	-	GET or POST			
*/
function fillInControls( target , submissionType , showComment ){
 submissionType =  submissionType.toLowerCase(); 
 
	$('#'+target).addClass('controller box');

	var $ctrls = 
		$('#'+target)
			.append( $('<div/>') );
			
	for( var x in Cmds ) {  
		var cmd = x;
		if(!!Cmds[x] && Cmds[x] != "") 
			cmd = Cmds[x];
		
		$ctrls
			.append( 
				$('<img/>')			//img
					.attr('id','formSubmit_manual_'+x+'-'+ submissionType)
					.attr('name' , x )
					.attr('title' , x )
					.attr('src' , '/img/'+x+'.png' )	//img
					.attr('alt' , x )									//img
					.click(function(e) {
						var val = e.target.name;
						flashMessage( val );

						// if the "Enable Extended Features" options is present and selected, 
						//	- then allow the in-extension loading
						var url = "index.php";
						if (!!localStorage["options"] 
									&& !!JSON.parse(localStorage["options"]) 
									&& !!JSON.parse(localStorage["options"])["iTunes URL"] 
									&& JSON.parse(localStorage["options"])["iTunes URL"]["value"])
							url = JSON.parse(localStorage["options"])["iTunes URL"]["value"];

						$.post(
							url
							, { "ajax":true
									, "cachebust": (new Date().getTime().toString())
									, "command": val }
							, function( response , status , xhr ) { // response callback
									localStorage["songData"] = response;
									try {
										window.songData = JSON.parse(localStorage["songData"]);
									} catch(err) { 
										window.songData = localStorage["songData"];
									}
									fillSongData( window.songData );
							});
					})
				);
	}

	if(showComment)
		$('#'+target)
			.append( $('<span/>') 
			.html('(via HTTP '+submissionType+')') );
}

/* ================================================================================================ */
