/* ========================================================================================== */
/**	once the page has loaded, assign all the pertinent JS actions */
$('body').ready(function(e_TOP){
/* ++ ++ ++ ++ ++ ++ ++ ++ ++ ++ ++ ++ ++ ++ ++ ++ ++ ++ ++ ++ ++ ++ ++ ++ ++ ++ */	
	$('body').hide();	

	loadOptions();

	fillInControls( 'AJAX_controls' , 'AJAX' , false);

	getSongData();

	$('html').height( $('body').height() + 30 );
	$('body').height( $('body').height() );
	$('body').fadeIn(2000,'linear', function(){} );
	
/* ++ ++ ++ ++ ++ ++ ++ ++ ++ ++ ++ ++ ++ ++ ++ ++ ++ ++ ++ ++ ++ ++ ++ ++ ++ ++ */	
});


