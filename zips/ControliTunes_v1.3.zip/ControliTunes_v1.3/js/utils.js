/* --------------------------------------------- */
/** */ 
function getSongData(txt) {
	/* make an initial call to get a song's info */
	if (!!localStorage["options"] 
				&& !!JSON.parse(localStorage["options"]) 
				&& !!JSON.parse(localStorage["options"])["iTunes URL"] 
				&& JSON.parse(localStorage["options"])["iTunes URL"]["value"])
	{
		$.post(	JSON.parse(localStorage["options"])["iTunes URL"]["value"]
						, { "ajax":true , "cachebust": (new Date().getTime().toString()) , "command": "info" }
						, function( response , status , xhr ) { // response callback
								localStorage["songData"] = response;
								try{
									window.songData = JSON.parse(localStorage["songData"]);
								} catch(err) { 
									window.songData = response;
								}
								fillSongData( window.songData );
						});
	}
}
/* --------------------------------------------- */

/**	fill in the song data on the page if the necessary 
		info has been passed to the client via PHP */
songDataRefresh=null;
function fillSongData(data) {
		
	if(!!!data || !!!(data.TITLE || data.ARTIST || data.ALBUM || data.VOLUME)) {
		if( $('title') ) {
			$('title').each(function(i,t){ $(t).html("Control iTunes"); });
		}
		$('#songDataContainer').empty();
		clearInterval(songDataRefresh);
		return;
	}
	
	/* change page title: */
	if( $('title') ) {
		$('title').each(function(i,t){ $(t).html( data["TITLE"] + " - " + data["ARTIST"]); });
	}
	
	/* build progress bar... */
	$('#songDataProgBarMask').width(((data['PERCENT'] * $('#songDataProgBar').width())/100) );
	
		if (!!localStorage["options"] 
				&& !!JSON.parse(localStorage["options"]) 
				&& !!JSON.parse(localStorage["options"])["Show Percentage"] 
				&& JSON.parse(localStorage["options"])["Show Percentage"]["checked"]) 
		{
			$('#songDataProgBarMask').html( data['PERCENT'] + "%" );
		}
		
	/* clear out the song data container */
	$('#songDataContainer').empty();
	
	/* re-populate the song data on the page: */
	for( var x in CmdCats ) { 
		if(!CmdCats[x]) {
			continue;
		}
		
		$('#songDataContainer')
			.append(
				$('<div/>')
					.addClass('dataName')
					.addClass('left')
					.html(x+':'))
			.append(
				$('<div/>')
					.addClass('songData')
					.addClass('left')
					.html( /* get the songs with no seconds in duration (#:0) to look like "#:00" */ 
						(data[x].match(/[\d]*:0$/)) ? 
							(data[x]+'0') : 
							(data[x]) ))
			.append( $(document.createElement('br')).addClass('clear') );
	}
		
	if( !!!songDataRefresh ) {
		songDataRefresh = setInterval( function(){ getSongData(); } , 1*1000);
	}
}