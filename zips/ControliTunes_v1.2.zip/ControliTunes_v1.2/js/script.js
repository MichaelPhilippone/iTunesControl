/* ========================================================================================== */
/**	once the page has loaded, assign all the pertinent JS actions */
$('body').ready(function(e_TOP){

	$('body').hide();
	
	loadOptions();

	/* fill in controller buttones where necessary: */
	for( var x in HTTPtypes ) {  
		if(!HTTPtypes[x]) 
			continue;
		fillInControls( x+'_controls' , x , false);
	}

	/* make sure we are posting the form only if there is a command to perform */	
	$('#POST_form').submit(function(){ 
		return ( !!$('#command').attr('value') && $('#command').attr('value') != '' ); 
	});
	
	getSongData();

	$('html').height( $('body').height() + 30 );
	$('body').height( $('body').height() );
	$('body').fadeIn(2000,'linear', function(){} );
});


