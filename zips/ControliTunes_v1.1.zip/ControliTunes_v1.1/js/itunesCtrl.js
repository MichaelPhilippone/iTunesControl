/* ************************************************************************************
 * 	OBJECT:		
 * 	AUTHOR:		Michael Philippone
 *	DATE:			05 JAN 2011
 *	PURPOSE:	
************************************************************************************ */
/* ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** **  */
/**	GLOBAL VARS */
var CmdCats = {"ARTIST":true,"TITLE":true,"ALBUM":true,"VOLUME":0,"POSITION":0,"DURATION":1,"PERCENT":0};
var HTTPtypes = {"GET":0,"POST":0,"AJAX":true};
var Cmds = {"play":">","pause":"#","previous":"<--","next":"-->","volup":"Vol +","voldown":"Vol -"};
/* ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** **  */
/* ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** **  */

/**	once the page has loaded, assign all the pertinent JS actions 
			PARAM target					-	the element to fill in
			PARAM submissionType	-	GET or POST			
*/
function fillInControls( target , submissionType , showComment ){
 submissionType =  submissionType.toLowerCase(); 
 
	$('#'+target).addClass('controller box');
		
	$('#'+target)
		.append($('<img/>')
			.attr('src','img/music.jpg')
			.attr('id','pageIcon')
			.attr('alt','iTunes Web Control') );
		
	$('#'+target)
		.append($('<div/>')
			.addClass('controllerTitle')
			.html('Control iTunes') );

	$('#'+target)
		.append($('<div/>')
		.addClass('clear') );


	var $ctrls = 
		$('#'+target)
			.append( $('<div/>') );
			
	for( var x in Cmds ) {  
		var cmd = x;
		if(!!Cmds[x] && Cmds[x] != "") 
			cmd = Cmds[x];
		
		$ctrls
			.append( 
				//$('<a/>')			//link
				$('<img/>')			//img
				//$('<input/>')	//btn
					.attr('id','formSubmit_manual_'+x+'-'+ submissionType)
					.attr('name' , x )
					.attr('title' , x )
					//.attr('type','button')	//btn
					//.attr('value' , cmd )		//btn
					//.attr('href' , '#' ) 		//link
					//.html(cmd)							//link
					.attr('src' , 'img/'+x+'.png' )	//img
					.attr('alt' , x )								//img
					.click(function(e) {
						if( submissionType == 'get' ) {
							location.href= location.href + "?command=" + e.target.value ;
						} else if ( submissionType == 'post' ) {
							$('#command').attr('value', e.target.value ); 
							$('#POST_form').submit();
						} else if ( submissionType == 'ajax' ) {
							var val = e.target.name;
							flashMessage( val );

							// if the "Enable Extended Features" options is present and selected, 
							//	- then allow the in-extension loading
							var url = "index.php";
							if (!!localStorage["options"] 
										&& !!JSON.parse(localStorage["options"]) 
										&& !!JSON.parse(localStorage["options"])["iTunes URL"] 
										&& JSON.parse(localStorage["options"])["iTunes URL"]["value"])
								url = JSON.parse(localStorage["options"])["iTunes URL"]["value"];

							$.post(
								url
								, { "ajax":true
										, "cachebust": (new Date().getTime().toString())
										, "command": val }
								, function( response , status , xhr ) { // response callback
										localStorage["songData"] = response;
										try {
											window.songData = JSON.parse(localStorage["songData"]);
										} catch(err) { 
											window.songData = localStorage["songData"];
										}
										fillSongData( window.songData );
								});
						}
					})
				);
	}

	if(showComment)
		$('#'+target)
			.append( $('<span/>') 
			.html('(via HTTP '+submissionType+')') );
}

/* ================================================================================================ */
