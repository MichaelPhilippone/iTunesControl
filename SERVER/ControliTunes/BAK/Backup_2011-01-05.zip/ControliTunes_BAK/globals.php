<?
/* ================================================================================ */

/* TEST if this page's request includes an ajax signifier 
		in the GET or POST SuperGlobals: */
$AJAX = ( (isset($_GET['ajax']) && ( $_GET['ajax'] == 'true' || $_GET['ajax'] == true ))
				|| ( isset($_POST['ajax']) && ( $_POST['ajax'] == 'true' || $_POST['ajax'] == true ) ) );
//if( !$AJAX ) echo "<!-- NOT AJAX -->";

/* ================================================================================ */

/* set up the global var for where to run applescripts */
$ScriptsPath = "/Users/michael/Sites/ControliTunes/applescripts/";

/* ================================================================================ */

/* was it a POST method or GET? */
if( isset($_GET['command']) ) 
	$command = $_GET['command'];
else if( isset($_POST['command']) )
	$command = $_POST['command'];
	
/* ================================================================================ */
?>