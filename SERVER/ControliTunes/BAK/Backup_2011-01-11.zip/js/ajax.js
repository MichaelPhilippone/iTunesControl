/* --------------------------------------------- */
/** */
$('body').ready(function(){

	var controls = ["play","pause","next","previous","volup","voldown"];

	for( var i=0; i<controls.length; i++) 
		$('#controllerContent').append(
			$(document.createElement('input'))
				.attr("id", controls[i] )
				.attr("name", controls[i] )
				.attr("value", controls[i])
				.attr("type","button")
				.click(function(e){
						var val = e.currentTarget.value;
						var now = new Date().getTime().toString();
						flashMessage( val );
						$.post( 
							"index.php"
							, { "ajax":true
									, "cachebust": now
									, "q": val }
							, function( response , status , xhr ) { // response callback
									window.songData = JSON.parse(response);
									fillSongData();
									console.log( response );
							}
						);
				})
		);
});